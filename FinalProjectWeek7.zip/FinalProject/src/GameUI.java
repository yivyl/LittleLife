import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class GameUI extends JFrame {
    private Tamagotchi pet;
    private Player player;
    private Logic logic;
    public GameUI(Tamagotchi pet, Player player, Logic logic) {
    }
}